# Farm Friend — setup guide

Two files, one app:

| File | What it is |
|---|---|
| `farm_friend.html` | The whole app. One file. Open it in any browser — it works alone (weather, alerts, tips, guest mode, crop ideas, manual). |
| `farm_friend_app.py` | The backend. Adds NASA satellite plant health (NDVI, EVI) and AI advice + plant photo check. Serves the same HTML at http://127.0.0.1:8000 |

## Build and run (no coding needed)

1. Install Python 3.10 or newer.
2. Open a terminal in this folder and run:

```
pip install fastapi uvicorn requests pandas matplotlib python-dotenv
python farm_friend_app.py
```

3. Your browser opens http://127.0.0.1:8000 automatically. Done.

To use the app without the backend, just double-click `farm_friend.html`. Everything except the NASA satellite reading and AI answers works.

## Turn on the smart features (optional)

Create a file named `.env` next to `farm_friend_app.py`:

```
OPENAI_API_KEY=sk-your-key-here
EARTHDATA_USERNAME=your-nasa-username
EARTHDATA_PASSWORD=your-nasa-password
```

- **OpenAI key** — turns on AI advice and the plant photo check. Get one at platform.openai.com.
- **NASA Earthdata login** — free account at urs.earthdata.nasa.gov. Put it in `.env` once; farmers never see or type any login. (NASA requires every data user to have an account — that is why the field exists at all.)

Farmers can also pick "Other plant" in the questionnaire and type any plant name — the app adapts (generic tips, default heat limit).

## How the data flows

1. Farmer opens the app, adds a farm (big picture buttons, no reading needed).
2. Weather comes straight from Open-Meteo (updates every 30 minutes).
3. Press "Get my satellite reading" → the backend asks NASA AppEEARS for product **MOD13Q1.061**, layers **_250m_16_days_NDVI** and **_250m_16_days_EVI** → NDVI/EVI numbers, a graph, and simple AI advice come back. NASA can take 5–30 minutes.
4. "Check my plant" sends a photo to `/api/photo` → OpenAI answers in very simple words.

## Pairing with other code

The backend is a normal REST API (CORS open to all):

- `GET /api/health` — is it alive
- `POST /api/analyze` — start a NASA analysis (JSON: latitude, longitude, crop, growth_stage, irrigation, soil, start_date, end_date as DD-MM-YYYY)
- `GET /api/status/{job_id}` — progress
- `GET /api/results/{job_id}` — NDVI/EVI, observations, weather, AI advice, graph URL, CSV URL
- `POST /api/photo` — plant photo check ({image: dataURL, crop, stage, question})
- `GET /results/{job_id}/vegetation_graph.png` and `.csv` — the raw outputs

Any other program (Python, JavaScript, Excel Power Query...) can call these.

## Sources

- Weather: Open-Meteo (ECMWF/GFS models) — open-meteo.com
- Plant greenness: NASA MODIS MOD13Q1.061 via AppEEARS — appears.earthdatacloud.nasa.gov, lpdaac.usgs.gov/products/mod13q1v061
- AI: OpenAI — openai.com

Accuracy: weather forecasts are good for 1–2 days, less certain after 3 days. Satellite readings cover a 250 m square and refresh every 16 days. Always verify in the field.
