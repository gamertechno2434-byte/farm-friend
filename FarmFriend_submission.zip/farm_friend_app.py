"""Farm Friend: backend + website.

TWO files that work together:
  farm_friend.html   the whole app (open it directly, or let this server show it)
  farm_friend_app.py this backend (NASA satellite + AI advice + photo check)

Install:  pip install fastapi uvicorn requests pandas matplotlib python-dotenv
Run:      python farm_friend_app.py        (opens http://127.0.0.1:8000)

The website also works WITHOUT this backend (weather, alerts, tips, guest mode).
This backend adds: NASA satellite plant health (NDVI, EVI) and AI advice.

Optional .env file next to this script:
  OPENAI_API_KEY=sk-...            (turns on AI advice + plant photo check)
  EARTHDATA_USERNAME=...            (shared NASA login, so farmers need not type it)
  EARTHDATA_PASSWORD=...
"""
import os, time, uuid, threading, webbrowser
from pathlib import Path
from datetime import datetime

import requests
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()

NASA_API = "https://appeears.earthdatacloud.nasa.gov/api/"
WEATHER_API = "https://api.open-meteo.com/v1/forecast"
OPENAI_API = "https://api.openai.com/v1/chat/completions"
PRODUCT = "MOD13Q1.061"
OPENAI_MODEL = "gpt-4.1-mini"
HOST, PORT = "127.0.0.1", 8000

BASE_DIR = Path(__file__).resolve().parent
HTML_PATH = BASE_DIR / "farm_friend.html"
DATA_DIR = BASE_DIR / "results"
DATA_DIR.mkdir(parents=True, exist_ok=True)
jobs, jobs_lock = {}, threading.Lock()

app = FastAPI(title="Farm Friend", version="4.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False,
                   allow_methods=["GET", "POST"], allow_headers=["Content-Type"])
app.mount("/results", StaticFiles(directory=str(DATA_DIR)), name="results")


class FarmRequest(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    crop: str = Field(min_length=1, max_length=100)
    growth_stage: str = "Unknown"
    irrigation: str = "Unknown"
    soil: str = "Unknown"
    start_date: str
    end_date: str
    earthdata_username: str = ""
    earthdata_password: str = ""


class PhotoRequest(BaseModel):
    image: str = Field(min_length=20, description="data URL: data:image/...;base64,...")
    crop: str = ""
    stage: str = ""
    question: str = ""


def update_job(job_id, **v):
    with jobs_lock:
        if job_id in jobs:
            jobs[job_id].update(v)


def get_job(job_id):
    with jobs_lock:
        j = jobs.get(job_id)
        return dict(j) if j else None


# ---------- NASA AppEEARS ----------
def api_get(session, url):
    r = session.get(url, timeout=45)
    r.raise_for_status()
    return r.json()


def authenticate(session, user, pw):
    r = session.post(NASA_API + "login", auth=(user, pw),
                     data={"grant_type": "client_credentials"}, timeout=45)
    r.raise_for_status()
    token = r.json().get("token")
    if not token:
        raise RuntimeError("NASA did not return a login token.")
    session.headers.update({"Authorization": f"Bearer {token}"})


def discover_layers(session):
    names = list(api_get(session, f"{NASA_API}product/{PRODUCT}").keys())
    ndvi = next((n for n in names if n.lower() == "_250m_16_days_ndvi"), None)
    evi = next((n for n in names if n.lower() == "_250m_16_days_evi"), None)
    if not ndvi or not evi:
        raise RuntimeError("Could not find the MODIS NDVI and EVI layers.")
    return ndvi, evi


def create_task(session, farm):
    ndvi, evi = discover_layers(session)
    task = {"task_type": "point", "task_name": "farm_ai_" + uuid.uuid4().hex[:8],
            "params": {"dates": [{"startDate": farm.start_date, "endDate": farm.end_date}],
                       "layers": [{"product": PRODUCT, "layer": ndvi}, {"product": PRODUCT, "layer": evi}],
                       "coordinates": [{"id": "farm", "latitude": farm.latitude, "longitude": farm.longitude}]}}
    r = session.post(NASA_API + "task", json=task, timeout=60)
    r.raise_for_status()
    tid = r.json().get("task_id")
    if not tid:
        raise RuntimeError("NASA did not return a task ID.")
    return tid


def wait_for_task(session, task_id, job_id):
    t0 = time.monotonic()
    while True:
        st = str(api_get(session, f"{NASA_API}task/{task_id}").get("status", "unknown")).lower()
        update_job(job_id, nasa_status=st, message=f"NASA is working (status: {st})")
        if st == "done":
            return
        if st in {"error", "failed", "cancelled"}:
            raise RuntimeError(f"NASA task ended with status: {st}")
        if time.monotonic() - t0 > 3600:
            raise TimeoutError("NASA processing timed out.")
        time.sleep(15)


def download_files(session, task_id, job_dir):
    files = api_get(session, f"{NASA_API}bundle/{task_id}").get("files", [])
    csvs = []
    for it in files:
        fid = it.get("file_id")
        if not fid:
            continue
        r = session.get(f"{NASA_API}bundle/{task_id}/{fid}", timeout=180)
        r.raise_for_status()
        dest = job_dir / Path(it.get("file_name", "output")).name
        dest.write_bytes(r.content)
        if dest.suffix.lower() == ".csv":
            csvs.append(dest)
    if not csvs:
        raise RuntimeError("NASA returned no CSV files.")
    return csvs


def find_column(cols, key):
    key = key.lower()
    for c in cols:
        if str(c).strip().lower() == key:
            return c
    for c in cols:
        if key in str(c).lower():
            return c
    return None


def load_data(csvs):
    frames = []
    for f in csvs:
        df = pd.read_csv(f)
        if df.empty:
            continue
        nc, ec, dc = (find_column(df.columns, k) for k in ("NDVI", "EVI", "Date"))
        if not dc or (not nc and not ec):
            continue
        fr = pd.DataFrame()
        fr["_date"] = pd.to_datetime(df[dc], errors="coerce")
        fr["_ndvi"] = pd.to_numeric(df[nc], errors="coerce") if nc else float("nan")
        fr["_evi"] = pd.to_numeric(df[ec], errors="coerce") if ec else float("nan")
        for c in ("_ndvi", "_evi"):
            v = fr[c].dropna()
            if not v.empty and v.abs().median() > 1.5:
                fr[c] *= 0.0001  # MODIS scale factor
            fr.loc[~fr[c].between(-1, 1), c] = float("nan")
        frames.append(fr)
    if not frames:
        raise RuntimeError("Could not find NDVI/EVI columns and dates in the NASA files.")
    d = pd.concat(frames, ignore_index=True).dropna(subset=["_date"])
    d = d.groupby("_date", as_index=False).agg({"_ndvi": "first", "_evi": "first"}).sort_values("_date")
    d = d.dropna(subset=["_ndvi", "_evi"], how="all")
    if d.empty:
        raise RuntimeError("No valid vegetation readings found.")
    return d


# ---------- weather, AI, graph ----------
def get_weather(lat, lon):
    r = requests.get(WEATHER_API, timeout=30, params={
        "latitude": lat, "longitude": lon,
        "current": "temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m",
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,et0_fao_evapotranspiration",
        "forecast_days": 7, "timezone": "auto"})
    r.raise_for_status()
    return r.json()


SYSTEM_PROMPT = """You are a friendly farm adviser for farmers who may not read well.
Use the satellite greenness readings (NDVI, EVI) and the weather to help.
Write VERY short sentences and simple everyday words. No jargon. Use at most 8 bullet points,
each starting with what to DO. Cover: how the plants look now, whether they are getting better or
worse, watering, soil and food for the plants, what to check in the field, and what extra
information would help.
Rules: say what you SEE (readings) separately from what you GUESS. Never name a disease from NDVI/EVI
alone. Never invent yield numbers. Never give fertiliser or pesticide amounts; say to read the product
label and ask a local agriculture officer. Say when you are unsure. Tell the farmer to check the field."""


PHOTO_PROMPT = """You are a crop helper for farmers who may not read well. You get ONE photo of a plant.
Write VERY short sentences, simple everyday words, no jargon. At most 6 bullet points, each starting
with what to DO (for example: "Water less.", "Look under the leaves."). Describe only what is clearly
visible in the photo (leaf colour, spots, holes, wilting, insects, soil). If the photo is blurry or
the plant is not clear, say so and tell the farmer to take a new photo in daylight. Never be sure
about a disease from one photo; say "may be" and tell the farmer to ask a local agriculture officer.
Never give fertiliser or pesticide amounts. Answer the farmer's question if there is one."""


def generate_advice(farm, data, weather):
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return {"mode": "basic", "advice": "AI advice is off. Add OPENAI_API_KEY to the .env file to turn it on."}
    rnd = lambda x: round(float(x), 4) if pd.notna(x) else None
    obs = [{"date": str(r["_date"].date()), "ndvi": rnd(r["_ndvi"]), "evi": rnd(r["_evi"])}
           for _, r in data.tail(8).iterrows()]
    ctx = {"crop": farm.crop, "growth_stage": farm.growth_stage, "irrigation": farm.irrigation,
           "soil": farm.soil, "observations": obs, "weather": weather}
    r = requests.post(OPENAI_API, timeout=90,
                      headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                      json={"model": OPENAI_MODEL, "temperature": 0.3,
                            "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                                         {"role": "user", "content": str(ctx)}]})
    r.raise_for_status()
    try:
        return {"mode": "ai", "advice": r.json()["choices"][0]["message"]["content"]}
    except (KeyError, IndexError, TypeError):
        raise RuntimeError("OpenAI returned an unexpected answer.")


def create_graph(data, job_dir):
    fig, ax = plt.subplots(figsize=(10, 5))
    if data["_ndvi"].notna().any():
        ax.plot(data["_date"], data["_ndvi"], marker="o", label="NDVI")
    if data["_evi"].notna().any():
        ax.plot(data["_date"], data["_evi"], marker="s", label="EVI")
    ax.set_title("Farm plant greenness (higher is healthier)")
    ax.set_xlabel("Date")
    ax.set_ylabel("Index")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(job_dir / "vegetation_graph.png", dpi=160)
    plt.close(fig)


# ---------- main job ----------
def process_farm(job_id, farm):
    s = requests.Session()
    try:
        job_dir = DATA_DIR / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        update_job(job_id, status="running", message="Logging in to NASA...")
        s.headers.update({"Accept": "application/json"})
        authenticate(s, farm.earthdata_username, farm.earthdata_password)
        update_job(job_id, message="Sending satellite request...")
        tid = create_task(s, farm)
        update_job(job_id, nasa_task_id=tid, message="NASA is preparing your data. This can take 5 to 30 minutes.")
        wait_for_task(s, tid, job_id)
        update_job(job_id, message="Downloading satellite data...")
        data = load_data(download_files(s, tid, job_dir))
        create_graph(data, job_dir)
        rnd = lambda x: round(float(x), 4) if pd.notna(x) else None
        summary = [{"date": str(r["_date"].date()), "ndvi": rnd(r["_ndvi"]), "evi": rnd(r["_evi"])}
                   for _, r in data.iterrows()]
        data[["_date", "_ndvi", "_evi"]].to_csv(job_dir / "vegetation_data.csv", index=False)
        update_job(job_id, message="Checking local weather...")
        try:
            weather = get_weather(farm.latitude, farm.longitude)
        except Exception:
            weather = {"error": "Weather is temporarily unavailable."}
        update_job(job_id, message="Writing advice...")
        try:
            advice = generate_advice(farm, data, weather)
        except Exception:
            advice = {"mode": "fallback", "advice": "Satellite data is ready, but AI advice failed. Check OPENAI_API_KEY and try again."}
        latest = summary[-1]
        update_job(job_id, status="completed", message="Done.", error=None, results={
            "crop": farm.crop, "growth_stage": farm.growth_stage,
            "coordinates": {"latitude": farm.latitude, "longitude": farm.longitude},
            "ndvi": latest["ndvi"], "evi": latest["evi"], "latest": latest,
            "observations": summary, "weather": weather, "recommendations": advice,
            "graph_url": f"/results/{job_id}/vegetation_graph.png",
            "csv_url": f"/results/{job_id}/vegetation_data.csv"})
    except Exception as e:
        print(f"Job {job_id} failed: {type(e).__name__}: {e}")
        update_job(job_id, status="failed", message="Failed.", error=str(e))
    finally:
        s.close()
        farm.earthdata_username = farm.earthdata_password = ""


# ---------- routes ----------
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def website():
    try:
        return HTML_PATH.read_text(encoding="utf-8")
    except FileNotFoundError:
        return "<h1>Farm Friend</h1><p>Put farm_friend.html next to farm_friend_app.py and start again.</p>"


@app.get("/api/health")
def health():
    return {"name": "Farm Friend", "status": "online", "version": "4.0.0",
            "nasa_login_in_env": bool(os.getenv("EARTHDATA_USERNAME") and os.getenv("EARTHDATA_PASSWORD")),
            "ai_on": bool(os.getenv("OPENAI_API_KEY"))}


@app.post("/api/analyze")
def analyze(farm: FarmRequest, background_tasks: BackgroundTasks):
    try:
        start = datetime.strptime(farm.start_date, "%d-%m-%Y")
        end = datetime.strptime(farm.end_date, "%d-%m-%Y")
        if start > end or end.date() > datetime.now().date():
            raise ValueError
    except ValueError:
        raise HTTPException(400, "Check the dates: start must be before end, and end cannot be in the future.")
    farm.earthdata_username = farm.earthdata_username or os.getenv("EARTHDATA_USERNAME", "")
    farm.earthdata_password = farm.earthdata_password or os.getenv("EARTHDATA_PASSWORD", "")
    if not farm.earthdata_username or not farm.earthdata_password:
        raise HTTPException(400, "NASA login needed. Type it in the form, or put EARTHDATA_USERNAME and EARTHDATA_PASSWORD in the .env file.")
    job_id = str(uuid.uuid4())
    with jobs_lock:
        jobs[job_id] = {"status": "queued", "message": "Waiting to start...", "nasa_status": None,
                        "nasa_task_id": None, "results": None, "error": None}
    background_tasks.add_task(process_farm, job_id, farm)
    return {"job_id": job_id, "status": "queued", "message": "Started."}


@app.get("/api/status/{job_id}")
def status(job_id: str):
    j = get_job(job_id)
    if not j:
        raise HTTPException(404, "Job not found. The server may have restarted.")
    return {"job_id": job_id, "status": j["status"], "message": j["message"],
            "nasa_status": j["nasa_status"], "error": j["error"]}


@app.get("/api/results/{job_id}")
def results(job_id: str):
    j = get_job(job_id)
    if not j:
        raise HTTPException(404, "Job not found. The server may have restarted.")
    if j["status"] != "completed":
        raise HTTPException(409, "Not finished yet.")
    return j["results"]


@app.post("/api/photo")
def photo_check(body: PhotoRequest):
    """AI looks at one plant photo and writes simple advice. Needs OPENAI_API_KEY."""
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return {"advice": "The photo check is switched off on this server. Add OPENAI_API_KEY to the .env file, restart, and try again."}
    if not body.image.startswith("data:image/"):
        raise HTTPException(400, "Send the photo as a data URL: data:image/...;base64,...")
    ctx = f"Crop: {body.crop or 'unknown'}. Growth stage: {body.stage or 'unknown'}."
    if body.question:
        ctx += f"\nFarmer asks: {body.question}"
    r = requests.post(OPENAI_API, timeout=90,
                      headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                      json={"model": OPENAI_MODEL, "temperature": 0.3,
                            "messages": [
                                {"role": "system", "content": PHOTO_PROMPT},
                                {"role": "user", "content": [
                                    {"type": "text", "text": ctx},
                                    {"type": "image_url", "image_url": {"url": body.image}}]}]})
    r.raise_for_status()
    try:
        return {"advice": r.json()["choices"][0]["message"]["content"]}
    except (KeyError, IndexError, TypeError):
        raise RuntimeError("OpenAI returned an unexpected answer for the photo.")


@app.get("/api/jobs")
def all_jobs():
    with jobs_lock:
        return [{"job_id": k, "status": v["status"], "message": v["message"]} for k, v in jobs.items()]


if __name__ == "__main__":
    threading.Timer(1.5, lambda: webbrowser.open(f"http://{HOST}:{PORT}")).start()
    uvicorn.run(app, host=HOST, port=PORT)
